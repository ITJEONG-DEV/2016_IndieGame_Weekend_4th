## Margin and Spacing Tests ##

The files found in this folder are margin and spacing tests for Dusk.

In each of these tests, the margin and spacing is adjusted to get the same effect in Tiled. That means that all these should render indentically in Dusk (which means the margin and spacing system is working correctly).

## Result ##

These tests were last run successfully for version 0.1.4 of Dusk.