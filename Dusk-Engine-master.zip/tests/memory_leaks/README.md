## Memory Leak Tests ##

The files in this folder are for Dusk memory leak checking. This is to make sure the `map.destroy()` command properly deletes all associated resources, and memory levels do not rise.

#### Result ####

These tests were last run successfully for version 0.1.4 of Dusk.