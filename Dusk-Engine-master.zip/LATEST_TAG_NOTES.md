### Release Notes for Dusk v0.2

I've been using the dev version in my personal game for quite a while, and everything's working as expected. Thus, Dusk v0.2 is just a simple bump of the dev version to the stable branch.
