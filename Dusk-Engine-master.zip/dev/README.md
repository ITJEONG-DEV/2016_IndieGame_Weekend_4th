### Dev Folder

This is my brainstorming and ideas folder.
