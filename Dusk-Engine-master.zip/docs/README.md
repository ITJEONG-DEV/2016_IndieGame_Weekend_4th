### Dusk Documentation

This is going to be the Dusk engine documentation when it's finished. Right now, it uses a very simplistic documentation generator written specifically for this purpose, but it still is pretty usable.

It's by no means complete, but when it is, I'm planning on having this take the place of the documentation repository.

And yes, I know it's not presented in the best way. Hopefully this is temporary.
