## Dusk Demo: Spin ##

The Spin Dusk demo demonstrates non-Box2D physics (surface only) using tile properties.